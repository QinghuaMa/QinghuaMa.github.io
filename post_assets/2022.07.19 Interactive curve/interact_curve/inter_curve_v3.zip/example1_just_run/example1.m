clear classes

hf=figure;
ha=axes;
axis(ha,'manual');
ic=interactive_curve(hf,ha);